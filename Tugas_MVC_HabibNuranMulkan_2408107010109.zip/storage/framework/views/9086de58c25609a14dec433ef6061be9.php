<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Habib Futsal Arena</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('futsal.index')); ?>">HABIB<span>FUTSAL</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link <?php echo e(Route::is('futsal.index') ? 'active' : ''); ?>" href="<?php echo e(route('futsal.index')); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(Route::is('futsal.jadwal') ? 'active' : ''); ?>" href="<?php echo e(route('futsal.jadwal')); ?>">Jadwal Booking</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(Route::is('futsal.contact') ? 'active' : ''); ?>" href="<?php echo e(route('futsal.contact')); ?>">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container" style="margin-top: 130px; margin-bottom: 60px;">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Informatics\pbw\example-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>